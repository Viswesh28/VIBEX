export * from './artist.service'
